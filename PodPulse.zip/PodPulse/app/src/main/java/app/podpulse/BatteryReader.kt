package app.podpulse

import android.annotation.SuppressLint
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Reads earbud battery levels using the three standard routes Android offers.
 * Which one works depends on what your earbuds report. Many clone earbuds only
 * report one combined number, so [Levels.single] is the value most people will see.
 */
@SuppressLint("MissingPermission")
class BatteryReader(private val context: Context) {

    data class Levels(
        val left: Int? = null,
        val right: Int? = null,
        val case: Int? = null,
        val single: Int? = null,
    ) {
        val hasAny get() = left != null || right != null || case != null || single != null
    }

    /** Paired devices that Android classifies as audio devices. */
    fun bondedAudio(): List<BluetoothDevice> {
        val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        val bonded = adapter.bondedDevices.orEmpty()
        val audio = bonded.filter { it.bluetoothClass?.majorDeviceClass == BluetoothClass.Device.Major.AUDIO_VIDEO }
        // Some clone earbuds do not declare themselves as audio devices, so fall back to every paired device.
        return (audio.ifEmpty { bonded.toList() }).sortedBy { it.name ?: "" }
    }

    /** Live battery levels for one paired device. */
    @Suppress("DEPRECATION")
    fun levels(device: BluetoothDevice): Flow<Levels> = callbackFlow {
        fun push(v: Int) {
            if (v in 0..100) trySend(Levels(single = v))
        }

        // Route 1: the system broadcasts a battery level for headsets that report over
        // the headset profile. The action name is stable but not in the public SDK.
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                if (d?.address != device.address) return
                push(i.getIntExtra(EXTRA_BATTERY_LEVEL, -1))
            }
        }
        ContextCompat.registerReceiver(
            context, receiver, IntentFilter(ACTION_BATTERY_LEVEL_CHANGED), ContextCompat.RECEIVER_EXPORTED
        )

        // Route 3: standard Bluetooth LE Battery Service (0x180F / 0x2A19).
        var gatt: BluetoothGatt? = null
        fun readBattery(g: BluetoothGatt) {
            g.getService(BATTERY_SERVICE)?.getCharacteristic(BATTERY_LEVEL)?.let { g.readCharacteristic(it) }
        }
        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) = readBattery(g)

            override fun onCharacteristicRead(
                g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: ByteArray, status: Int
            ) {
                if (ch.uuid == BATTERY_LEVEL && value.isNotEmpty()) push(value[0].toInt() and 0xFF)
            }

            // Android 12 and older call this version instead.
            override fun onCharacteristicRead(g: BluetoothGatt, ch: BluetoothGattCharacteristic, status: Int) {
                val v = ch.value
                if (ch.uuid == BATTERY_LEVEL && v != null && v.isNotEmpty()) push(v[0].toInt() and 0xFF)
            }
        }
        gatt = runCatching { device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE) }.getOrNull()

        // Route 2 plus refresh: ask the system for its cached value, and re-read GATT.
        val poll = launch {
            while (true) {
                val v = runCatching {
                    BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(device) as Int
                }.getOrNull()
                if (v != null && v >= 0) push(v)
                gatt?.let { readBattery(it) }
                delay(10_000)
            }
        }

        awaitClose {
            poll.cancel()
            runCatching { context.unregisterReceiver(receiver) }
            runCatching { gatt?.close() }
        }
    }

    /** Simulated levels for trying the app without earbuds. */
    fun demoLevels(): Flow<Levels> = flow {
        var l = 82; var r = 79; var c = 64
        while (true) {
            emit(Levels(left = l, right = r, case = c))
            delay(5_000)
            if (l > r) l-- else r--
        }
    }

    private companion object {
        const val ACTION_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"
        val BATTERY_SERVICE: UUID = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb")
        val BATTERY_LEVEL: UUID = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb")
    }
}
