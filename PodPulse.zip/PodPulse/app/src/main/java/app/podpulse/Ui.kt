package app.podpulse

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

private val Bg = Color(0xFF0C0B13)
private val Card = Color(0xFF171524)
private val Card2 = Color(0xFF221F34)
private val Fg = Color(0xFFF1F0F9)
private val Muted = Color(0xFFA09EB5)
private val Ink = Color(0xFF0F0D18)
private val Warn = Color(0xFFFF7A63)

private enum class Phase { Pick, Pairing, Home }

/** hue = null means the dynamic theme that slowly cycles through colors. */
private data class AccentTheme(val name: String, val hue: Float?)

private val themes = listOf(
    AccentTheme("Aurora", 262f),
    AccentTheme("Ember", 14f),
    AccentTheme("Mint", 158f),
    AccentTheme("Rose", 330f),
    AccentTheme("Dynamic", null),
)

@SuppressLint("MissingPermission")
@Composable
fun PodPulseApp(reader: BatteryReader, granted: Boolean) {
    var themeIdx by remember { mutableIntStateOf(0) }
    val cycle = rememberInfiniteTransition(label = "hue")
    val dynamicHue by cycle.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(24_000, easing = LinearEasing)), label = "h",
    )
    val hue = themes[themeIdx].hue ?: dynamicHue
    val accent = Color.hsv(hue, 0.6f, 1f)
    val accent2 = Color.hsv((hue + 55f) % 360f, 0.6f, 1f)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent, onPrimary = Ink, background = Bg, surface = Card,
            onBackground = Fg, onSurface = Fg,
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            var phase by remember { mutableStateOf(Phase.Pick) }
            var device by remember { mutableStateOf<BluetoothDevice?>(null) }
            var demo by remember { mutableStateOf(false) }

            Crossfade(targetState = phase, animationSpec = tween(600), label = "phase") { p ->
                when (p) {
                    Phase.Pick -> PickScreen(
                        reader = reader, granted = granted, accent = accent,
                        onDevice = { device = it; demo = false; phase = Phase.Pairing },
                        onDemo = { device = null; demo = true; phase = Phase.Pairing },
                    )
                    Phase.Pairing -> PairingScreen(accent = accent, onDone = { phase = Phase.Home })
                    Phase.Home -> HomeScreen(
                        reader = reader, device = device, demo = demo,
                        accent = accent, accent2 = accent2,
                        themeIdx = themeIdx, onTheme = { themeIdx = it },
                        onSwitch = { phase = Phase.Pick },
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- pick a device

@SuppressLint("MissingPermission")
@Composable
private fun PickScreen(
    reader: BatteryReader, granted: Boolean, accent: Color,
    onDevice: (BluetoothDevice) -> Unit, onDemo: () -> Unit,
) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val devices = remember(granted, refresh) { if (granted) reader.bondedAudio() else emptyList() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text("PodPulse", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Fg)
        Text(
            "Choose the earbuds you already paired in your phone's Bluetooth settings.",
            color = Muted, fontSize = 15.sp,
        )
        if (!granted) {
            Text("Allow Bluetooth access so PodPulse can see your paired devices.", color = Warn)
        }
        devices.forEach { d ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card)
                    .clickable { onDevice(d) }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(d.name ?: d.address, color = Fg, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("Connect", color = accent, fontWeight = FontWeight.Bold)
            }
        }
        if (granted && devices.isEmpty()) {
            Text("No paired audio devices found yet.", color = Muted)
        }
        OutlinedButton(
            onClick = { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Open Bluetooth settings") }
        OutlinedButton(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) { Text("Refresh list") }
        Button(
            onClick = onDemo, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Ink),
        ) { Text("Try demo without earbuds", fontWeight = FontWeight.Bold) }
    }
}

// ---------------------------------------------------------------- pairing animation

@Composable
private fun PairingScreen(accent: Color, onDone: () -> Unit) {
    // 0 = closed case, 1 = case opens, 2 = searching rings, 3 = connected
    var step by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        delay(400); step = 1
        delay(1500); step = 2
        delay(2400); step = 3
        delay(1300); onDone()
    }
    val title = listOf("Waking your earbuds", "Opening the case", "Connecting", "Connected")[step]

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        PairingScene(step = step, accent = accent)
        Spacer(Modifier.height(20.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Fg, textAlign = TextAlign.Center)
    }
}

@Composable
private fun PairingScene(step: Int, accent: Color) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val t by pulse.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "t",
    )
    val open by animateFloatAsState(if (step >= 1) 1f else 0f, tween(900), label = "open")
    val rise by animateFloatAsState(
        if (step >= 1) 1f else 0f, tween(1000, delayMillis = 350, easing = FastOutSlowInEasing), label = "rise",
    )
    val check by animateFloatAsState(if (step >= 3) 1f else 0f, tween(500), label = "check")

    Canvas(Modifier.size(300.dp, 230.dp)) {
        val cx = size.width / 2
        val baseY = size.height * 0.62f
        val caseW = 180.dp.toPx()
        val caseH = 90.dp.toPx()
        val body = Card2
        val lidColor = Color(0xFF2D2A45)

        if (step >= 2) {
            repeat(3) { i ->
                val p = (t + i / 3f) % 1f
                drawCircle(
                    color = accent.copy(alpha = (1f - p) * 0.6f),
                    radius = 50.dp.toPx() + p * 110.dp.toPx(),
                    center = Offset(cx, baseY),
                    style = Stroke(2.dp.toPx()),
                )
            }
        }

        // case body
        drawRoundRect(body, Offset(cx - caseW / 2, baseY), Size(caseW, caseH), CornerRadius(40.dp.toPx()))

        fun drawLid() {
            val lidH = 46.dp.toPx() * (1f - open * 0.7f)
            val lidY = baseY + 12.dp.toPx() - open * 50.dp.toPx() - lidH
            drawRoundRect(lidColor, Offset(cx - caseW / 2, lidY), Size(caseW, lidH), CornerRadius(34.dp.toPx()))
        }
        val lidOnTop = open < 0.5f
        if (!lidOnTop) drawLid()

        // earbuds rising out of the case
        val budR = 20.dp.toPx()
        val lift = rise * 62.dp.toPx()
        listOf(-1f, 1f).forEach { s ->
            val c = Offset(cx + s * 38.dp.toPx(), baseY + 20.dp.toPx() - lift)
            drawOval(Color(0xFFE8E7F3), Offset(c.x - budR, c.y - budR * 1.2f), Size(budR * 2, budR * 2.4f))
            if (step >= 2) drawCircle(accent, 4.dp.toPx(), Offset(c.x + s * 8.dp.toPx(), c.y - 10.dp.toPx()))
        }

        // front of the case hides the lower half of the earbuds
        drawRoundRect(
            body, Offset(cx - caseW / 2, baseY + 12.dp.toPx()),
            Size(caseW, caseH - 12.dp.toPx()), CornerRadius(34.dp.toPx()),
        )
        if (lidOnTop) drawLid()
        drawCircle(if (step >= 1) accent else Muted, 4.dp.toPx(), Offset(cx, baseY + caseH - 22.dp.toPx()))

        // check mark badge
        if (check > 0f) {
            val bc = Offset(cx, 28.dp.toPx())
            drawCircle(accent, 24.dp.toPx() * check, bc)
            val s = 24.dp.toPx() * check / 24f
            val a = Offset(bc.x - 10 * s, bc.y + 1 * s)
            val b = Offset(bc.x - 3 * s, bc.y + 9 * s)
            val c = Offset(bc.x + 11 * s, bc.y - 8 * s)
            drawLine(Ink, a, b, 4.dp.toPx(), StrokeCap.Round)
            drawLine(Ink, b, c, 4.dp.toPx(), StrokeCap.Round)
        }
    }
}

// ---------------------------------------------------------------- home

@SuppressLint("MissingPermission")
@Composable
private fun HomeScreen(
    reader: BatteryReader, device: BluetoothDevice?, demo: Boolean,
    accent: Color, accent2: Color, themeIdx: Int, onTheme: (Int) -> Unit, onSwitch: () -> Unit,
) {
    val flow = remember(device, demo) { if (demo || device == null) reader.demoLevels() else reader.levels(device) }
    val levels by flow.collectAsStateWithLifecycle(initialValue = BatteryReader.Levels())

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (demo) "Demo earbuds" else (device?.name ?: "Earbuds"),
                fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Fg,
            )
            Text(if (demo) "Simulated levels" else "Connected over Bluetooth", color = Muted, fontSize = 13.sp)
        }

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Card).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (levels.left != null || levels.right != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    BatteryRing("Left", levels.left, accent, accent2)
                    BatteryRing("Right", levels.right, accent, accent2)
                }
                levels.case?.let { CaseBar(it, accent, accent2) }
            } else if (levels.single != null) {
                BatteryRing("Earbuds", levels.single, accent, accent2)
                Text(
                    "Your earbuds report one combined level.",
                    color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            } else {
                Text(
                    "Waiting for a battery level. Some earbuds do not report one over standard Bluetooth.",
                    color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                )
            }
        }

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Card).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("APP THEME", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                themes.forEachIndexed { i, th ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(52.dp).clip(RoundedCornerShape(18.dp))
                                .background(swatch(th))
                                .border(2.dp, if (i == themeIdx) Fg else Color.Transparent, RoundedCornerShape(18.dp))
                                .clickable { onTheme(i) }
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(th.name, fontSize = 11.sp, color = if (i == themeIdx) Fg else Muted)
                    }
                }
            }
        }

        OutlinedButton(onClick = onSwitch, modifier = Modifier.fillMaxWidth()) { Text("Switch earbuds") }
    }
}

private fun swatch(th: AccentTheme): Brush =
    if (th.hue == null) Brush.sweepGradient(listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { Color.hsv(it % 360f, 0.6f, 1f) })
    else Brush.linearGradient(listOf(Color.hsv(th.hue, 0.6f, 1f), Color.hsv((th.hue + 55f) % 360f, 0.6f, 1f)))

@Composable
private fun BatteryRing(label: String, pct: Int?, accent: Color, accent2: Color) {
    val value = pct ?: 0
    val sweep by animateFloatAsState(value / 100f * 360f, tween(1400, easing = FastOutSlowInEasing), label = "sweep")
    val low = pct != null && pct < 20
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(128.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = Stroke(10.dp.toPx(), cap = StrokeCap.Round)
                val inset = 8.dp.toPx()
                val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
                drawArc(Card2, 0f, 360f, false, Offset(inset, inset), arcSize, style = stroke)
                drawArc(
                    brush = if (low) Brush.linearGradient(listOf(Warn, Warn)) else Brush.sweepGradient(listOf(accent, accent2, accent)),
                    startAngle = -90f, sweepAngle = sweep, useCenter = false,
                    topLeft = Offset(inset, inset), size = arcSize, style = stroke,
                )
            }
            Text(
                if (pct == null) "--" else "$pct%",
                fontSize = 26.sp, fontWeight = FontWeight.Bold, color = if (low) Warn else Fg,
            )
        }
        Text(label.uppercase(), color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    }
}

@Composable
private fun CaseBar(pct: Int, accent: Color, accent2: Color) {
    val w by animateFloatAsState(pct / 100f, tween(1400, easing = FastOutSlowInEasing), label = "case")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CASE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Box(Modifier.weight(1f).height(10.dp).clip(CircleShape).background(Card2)) {
            Box(
                Modifier.fillMaxWidth(w).height(10.dp).clip(CircleShape)
                    .background(if (pct < 20) Brush.linearGradient(listOf(Warn, Warn)) else Brush.horizontalGradient(listOf(accent, accent2)))
            )
        }
        Text("$pct%", color = Fg, fontWeight = FontWeight.Bold)
    }
}
