# PodPulse

An original companion app for Bluetooth earbuds. It shows battery, plays a pairing animation when you connect, and has switchable accent themes including a dynamic one.

## Build and install

1. Install Android Studio (current stable).
2. Choose File > Open and select this folder. Let Gradle sync. Android Studio creates the Gradle wrapper for you.
3. On your Samsung phone, turn on Developer options and USB debugging, then connect it by USB.
4. Press Run.

## Use

1. Pair your earbuds in the phone's Bluetooth settings first.
2. Open PodPulse, allow Bluetooth access, and tap your earbuds in the list.
3. The pairing animation plays, then the battery screen appears.
4. "Try demo without earbuds" shows the app with simulated levels.

## How battery is read

PodPulse tries three standard routes at once and shows whichever reports a value:

- The system battery broadcast for headsets that report over the headset profile.
- The system's cached battery value for the device.
- The Bluetooth LE Battery Service (0x180F, characteristic 0x2A19).

Most of these give one combined number. Separate left, right and case values need a vendor-specific protocol. If your earbuds send them, add a parser in `BatteryReader.kt` and fill `Levels.left`, `right` and `case`; the UI already shows rings and a case bar when those are set.

## Not included

Noise control, equalizer and find-my-earbuds need the earbuds' own command protocol, so they are not in the Android app yet. They exist only in the web prototype as visual demos.

## Status

Written but not compiled or run on a device yet. Expect small fixes on the first build.
